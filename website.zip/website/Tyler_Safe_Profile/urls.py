from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='profile-home'),
    path('contact/', views.contact, name='contact-info'),
    path('resume/', views.resume, name='resume-complete'),
    path('transcript/', views.transcript, name='academic-transcript'),

]