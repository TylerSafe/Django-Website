from django.apps import AppConfig


class TylerSafeProfileConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Tyler_Safe_Profile'
