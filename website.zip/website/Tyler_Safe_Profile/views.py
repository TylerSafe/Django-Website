from django.shortcuts import render
from django.http import HttpResponse



def home(request):
    return render(request, 'Tyler_Safe_Profile/home.html')

def contact(request):
    return render(request, 'Tyler_Safe_Profile/contact.html')